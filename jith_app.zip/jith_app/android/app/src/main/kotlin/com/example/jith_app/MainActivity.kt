package com.example.jith_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
